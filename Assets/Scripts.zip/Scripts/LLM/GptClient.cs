using UnityEngine;
using OpenAI;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System;

public class GptClient : ChatClient
{
    private OpenAIApi openAIApi;
    private List<ChatMessage> conversationHistory = new List<ChatMessage>();
    private readonly System.Random rng = new System.Random();
    string apiKey = "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";

    private void EnsureClientInitialized()
    {
        if (openAIApi != null)
            return;

        // Try to get API key if not set yet
        if (string.IsNullOrEmpty(apiKey))
        {
            var sm = SecretManager.Instance;
            if (sm == null)
            {
                Debug.LogError("SecretManager.Instance is null. Cannot initialize OpenAI client.");
                return;
            }

            apiKey = sm.GetGPTSecrets();
        }

        if (string.IsNullOrEmpty(apiKey))
        {
            Debug.LogError("OpenAI API key is missing or empty. Cannot initialize OpenAI client.");
            return;
        }

        openAIApi = new OpenAIApi(apiKey);
    }

    public override async Task<string> SendChatMessageAsync(string messageContent)
    {
        /*string first = conversationHistory.First().Content;
        string last = conversationHistory.Last().Content;
        string lastRole = conversationHistory.Last().Role;
        Debug.Log("Sending message: " + messageContent +"\n With following history: " + first + "\n and last message: " + lastRole + "  " + last);*/

        // Process the received message
        await SendMessageToAI(messageContent);

        if (conversationHistory.Count > 0)
        {
            // Assuming that the last message in the conversation history is the AI's response
            return conversationHistory[conversationHistory.Count - 1].Content;
        }
        return "No response generated.";

    }

    private async Task SendMessageToAI(string messageContent)       //maintain conversation history and send and receive OpenAI requests to the server
    {
        // Add user's message to history
        conversationHistory.Add(new ChatMessage { Role = "user", Content = messageContent });

        EnsureClientInitialized();
        if (openAIApi == null)
        {
            // fallback only
            string fallback = GenerateFallbackReply(messageContent);
            conversationHistory.Add(new ChatMessage { Role = "assistant", Content = fallback });
            return;
        }

        var request = new CreateChatCompletionRequest
        {
            Model = "gpt-4o-mini",
            Messages = conversationHistory,
            MaxTokens = 40, // Much shorter responses
            PresencePenalty = 1,
            FrequencyPenalty = 1,
        };

        try
        {
            var response = await openAIApi.CreateChatCompletion(request);
            string aiResponse = null;
            if (response.Choices != null && response.Choices.Count > 0)
            {
                aiResponse = response.Choices[0].Message.Content;

            }
            else
            {
                Debug.LogError("Failed to get response from AI");
                //throw new ChatClientFailedException();
                aiResponse = GenerateFallbackReply(messageContent);
            }
            conversationHistory.Add(new ChatMessage { Role = "assistant", Content = aiResponse });
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"LLM call failed, using fallback. Reason: {ex.Message}");
            var aiResponse = GenerateFallbackReply(messageContent);
            conversationHistory.Add(new ChatMessage { Role = "assistant", Content = aiResponse });
        }

    }

    public async Task<string> RequestGenericJsonAsync(string system, string user, string fallbackJson = "{}",
                                                  int maxTokens = 500)
    {
        EnsureClientInitialized();

        if (openAIApi == null)
        {
            Debug.LogWarning("OpenAI client not initialized; returning fallback JSON.");
            return fallbackJson;
        }

        var req = new CreateChatCompletionRequest
        {
            Model = "gpt-4o-mini",
            Messages = new List<ChatMessage>
            {
                new ChatMessage { Role = "system", Content = system },
                new ChatMessage { Role = "user",   Content = user   }
            },
            MaxTokens = maxTokens,
            Temperature = 0.2f,
            ResponseFormat = new ResponseFormat { Type = "json_object" }
        };

        try
        {
            var resp = await openAIApi.CreateChatCompletion(req);
            if (resp.Choices != null && resp.Choices.Count > 0)
                return resp.Choices[0].Message.Content;
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"Generic JSON request failed: {ex.Message}");
        }

        return fallbackJson;  // safe fallback for non-memory JSON
    }


    public async Task<string> RequestJsonAsync(string system, string user, int maxTokens = 500)
    {
        EnsureClientInitialized();
        if (openAIApi == null)
        {
            Debug.LogWarning("OpenAI client not initialized; returning empty memory JSON.");
            return @"{""core"":{},""social"":{},""thoughts"":{}}";
        }

        var req = new CreateChatCompletionRequest
        {
            Model = "gpt-4o-mini",        // cheaper, very good at JSON
            Messages = new List<ChatMessage>
            {
                new ChatMessage { Role = "system", Content = system },
                new ChatMessage { Role = "user",   Content = user   }
            },
            MaxTokens = maxTokens,
            Temperature = 0.2f,
            PresencePenalty = 0,
            FrequencyPenalty = 0,
            // IMPORTANT: force valid JSON
            ResponseFormat = new ResponseFormat
            {
                Type = "json_object"
            }
        };

        var resp = await openAIApi.CreateChatCompletion(req);
        return resp.Choices != null && resp.Choices.Count > 0
            ? resp.Choices[0].Message.Content
            : @"{""core"":{},""social"":{},""thoughts"":{}}";
    }

    private string Pick(string[] options) => options[rng.Next(options.Length)];

    private string GenerateFallbackReply(string userMessage)
    {
        // Special case: first-turn starter used by ConsoleChatbot
        if (userMessage.StartsWith("You are now speaking", StringComparison.OrdinalIgnoreCase))
        {
            var greet = Pick(new[]
            {
                "Hey there! Nice to see you around.",
                "Hi! Fancy running into you here.",
                "Hello! How’s your day going?",
                "Oh, hey! Been up to anything interesting?"
            });
            var follow = Pick(new[]
            {
                "What brings you here today?",
                "How are things on your side?",
                "Anything new happening?",
                "What are you working on?"
            });
            return $"{greet} {follow}";
        }

        // If user asked a question
        if (userMessage.Contains("?"))
        {
            var shortAnswer = Pick(new[]
            {
                "Good question—I'd say it depends.",
                "I think that makes sense.",
                "Probably, but I'd like to hear your take.",
                "Could be! What do you think?"
            });
            var bounce = Pick(new[]
            {
                "How do you see it?",
                "What’s your opinion?",
                "Curious what you’d choose.",
                "I’m open to ideas."
            });
            return $"{shortAnswer} {bounce}";
        }

        // Generic small-talk fallback
        var smallTalk = Pick(new[]
        {
            "I was just thinking about grabbing a drink from the well.",
            "Market’s busy today—lots of chatter.",
            "It’s a calm day; perfect for a short walk.",
            "Townhall looks lively; maybe there’s some meeting."
        });
        var promptBack = Pick(new[]
        {
            "How’s your day going?",
            "What are you up to?",
            "Anything interesting happening?",
            "Got any plans?"
        });
        return $"{smallTalk} {promptBack}";
    }

    public void SetSystemMessage(List<string> sessionHistory, NPC currentSpeaker, NPC npc1, string situationalContext = null)
    {
        conversationHistory.Clear();

        string coreBlock = string.IsNullOrWhiteSpace(currentSpeaker.memory.corePersonality)
        ? "(no core personality stored yet)"
        : currentSpeaker.memory.corePersonality.Trim();

        string socialSnippet = "";
        if (currentSpeaker.memory.socialByNpc != null && currentSpeaker.memory.socialByNpc.Count > 0)
        {
            foreach (var kv in currentSpeaker.memory.socialByNpc)
            {
                if (string.IsNullOrWhiteSpace(kv.Key) || string.IsNullOrWhiteSpace(kv.Value))
                    continue;

                socialSnippet += $"- {kv.Key}: {kv.Value.Trim()}\n";
            }
        }

        if (string.IsNullOrWhiteSpace(socialSnippet))
        {
            socialSnippet = "- You currently do not recall anything specific about other people.\n";
        }

        string thoughtsSnippet;
        if (currentSpeaker.memory.currentThoughts == null || currentSpeaker.memory.currentThoughts.Count == 0)
        {
            thoughtsSnippet = "- (no active short-term plans or worries)\n";
        }
        else
        {
            thoughtsSnippet = string.Join("\n", currentSpeaker.memory.currentThoughts
                .OrderByDescending(t => t.salience)
                .Select(t =>
                    $"- {t.text} [salience {Mathf.RoundToInt(t.salience * 100)}%, confidence {Mathf.RoundToInt(t.confidence * 100)}%]"
                ));
        }

        string knownPeople =
            (currentSpeaker.memory.socialByNpc != null && currentSpeaker.memory.socialByNpc.Count > 0)
            ? string.Join(", ", currentSpeaker.memory.socialByNpc.Keys)
            : "(no one yet)";

        string situationBlock = string.IsNullOrWhiteSpace(situationalContext)
            ? "- (no extra situational context)\n"
            : situationalContext.Trim() + "\n";

        // Build rumor snippet from RumorManager
        string rumorSnippet = "- (you haven't heard any rumors lately)\n";
        if (RumorManager.Instance != null)
        {
            var rumors = RumorManager.Instance.GetRumorsKnownBy(currentSpeaker.getName());
            if (rumors != null && rumors.Count > 0)
            {
                rumorSnippet = string.Join("\n", rumors.Select(r =>
                    $"- You heard from {r.heardFrom}: \"{r.currentText}\""));
            }
        }

        string sys = $@"
            You are {currentSpeaker.getName()}, a villager.
            Talk like a normal person.

            # You
            {coreBlock}

            # What you know
            {(string.IsNullOrWhiteSpace(socialSnippet) ? "- Not much yet\n" : socialSnippet)}

            # On your mind
            {thoughtsSnippet}

            # Rumors you've heard
            {rumorSnippet}

            # Here now
            {situationBlock}

            # RULES - VERY IMPORTANT
            - ONE sentence MAXIMUM
            - 5-8 words ideally
            - Simple words only
            - No long explanations
            - Normal chat, not AI talk
            - Use contractions
            - Ask short questions
            - Mention recent stuff naturally
            ";

        conversationHistory.Add(new ChatMessage { Role = "system", Content = sys });

        bool isNpc1Speaking = currentSpeaker == npc1;

        for (int i = 0; i < sessionHistory.Count; i++)
        {
            bool messageFromNpc1 = i % 2 == 0;

            conversationHistory.Add(new ChatMessage
            {
                Role = (messageFromNpc1 == isNpc1Speaking) ? "user" : "assistant",
                Content = sessionHistory[i]
            });
        }
    }
}